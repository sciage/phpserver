<?php

$con = mysqli_connect('candid-db.cfd1i0f6jekd.us-east-1.rds.amazonaws.com', 'F9ceab', 'hfhBMSKKy8h9y9YU', 'candid_db_test', 3306);

?>
